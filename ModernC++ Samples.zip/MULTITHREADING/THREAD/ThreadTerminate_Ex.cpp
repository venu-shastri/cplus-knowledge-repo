#include <iostream>
#include <thread>
#include <mutex>
using namespace std;

std::mutex mx;

class Interrupt:public exception
{
    public:
    const char* what() const noexcept override 
    {return "Interruption requested by thread...";}
};


void fun(int x)
{
    lock_guard<mutex> guard(mx);
    cout <<"************************" << endl;
    cout << "fun execution started...." << endl;

    if (x <= 0)
    {
        cout << "Terminating thread..." << endl;
        throw Interrupt();
    }

    cout << "fun executing statements gracefully without an exception..." << endl;
    cout << "fun execution completed..." << endl;
}

int main()
{
    auto lm =[](int x)
    {
        try
        {
            fun(x);
        }
        catch (const std::exception &e)
        {
            std::cerr << e.what() << '\n';
        }
    };

    //thread th1(lm, 10);
    
    thread th2(lm, 0);

    /*
    if(th1.joinable())
    {
        th1.join();
        cout <<"Thread 'th1' joined" << endl;
    }  
    */

    
    if(th2.joinable())
    {
        th2.join();
        cout <<"Thread 'th2' joined" << endl;
    }  
    
    return 0;
}